# ColorOS 7 Inspired Universal Android Launcher & ThemeGenerator

An offline-first, zero-API-key Android HOME replacement launcher for phones, tablets, and foldables that pairs a fluid ColorOS 7–inspired home screen, app drawer, folder system, widget host, and gesture engine with an onboard algorithmic `ThemeGenerator` screen.

## User Review & Critical Decisions

> [!IMPORTANT]
> Because the Phase 1 clarifying questions were skipped, this plan adopts the recommended defaults below. Review and approve to start implementation, or request revisions if you want any default changed.

- **Unified Launcher + `ThemeGenerator` Architecture (Recommended Default)**: Integrates the existing offline theme engine and introduces a dedicated **`ThemeGenerator` screen** directly inside the Launcher's personalization hub and Settings (`Themes` section), so generated palettes, glass effects, icon styles, and procedural wallpapers apply immediately to the live Home Screen, Dock, Folders, and App Drawer.
- **Visual Direction (Recommended Default)**: **ColorOS 7 Luminous Glass** (adaptive dark & light surfaces with translucent glassmorphism, squircle geometry, and wallpaper-extracted or prompt-generated accent palettes).
- **Zero-Blocker Privacy & Optional Permissions (Recommended Default)**: Core launcher features work offline with zero runtime permissions. Contacts search (`READ_CONTACTS`), Photo widgets (`PickVisualMedia`), and Double-Tap Lock (`DevicePolicyManager` admin) remain strictly **opt-in** from Settings, and OEM-restricted system actions are clearly labeled rather than simulated.
- **Dual Widget Engine (Recommended Default)**: Combines built-in zero-permission glass launcher widgets (Clock, Calendar, Battery, Notes, Photo, Search, Offline Weather Card, Media Controls) with real Android `AppWidgetHost` support for third-party app widgets.

---

## 1. Overview & Core Concept

- **What It Does**: Replaces or runs alongside the device's default home screen via Android's official `HOME` intent, giving users a multi-page customizable home grid, glass/transparent dock, vertical/horizontal app drawer, customizable folders, instant local search, gesture shortcuts, Home Screen Edit Mode, an onboard algorithmic `ThemeGenerator` screen, and a complete 15-section Settings Dashboard.
- **Target Audience**: Android smartphone, tablet, and foldable users seeking ColorOS 7–inspired polish, deep visual control, strict offline privacy (zero API keys, zero cloud accounts), and reliable responsiveness on both entry-level low-RAM phones and high-refresh-rate flagships.
- **Key Value**: Every visual layer—icons, folders, widgets, dock, drawer, transitions, and procedural wallpapers—is generated and persisted locally using Room and DataStore, while dynamically adapting rendering complexity across `Lite`, `Balanced`, and `Premium` hardware modes.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **First Launch & Default HOME Setup**:
   - Launcher initializes instantly from local Room/DataStore state (pre-populated with installed apps discovered via `LauncherApps` / `PackageManager` and sensible home pages + dock items).
   - A dismissible subtle pill or Settings banner guides users to set the app as Default Home via Android's system Home/Role chooser (`Settings.ACTION_HOME_SETTINGS` / `RoleManager.ROLE_HOME`) without blocking immediate use.
2. **Home Screen, Dock & Folder Interaction**:
   - Horizontal pager across multiple customizable home pages with smooth spring/depth/cube/parallax page transitions.
   - Drag/rearrange apps and widgets in **Home Screen Edit Mode**, drop icons onto one another to form **Folders** (Rounded, Glass, Transparent, Grid, or Stack styles), resize/configure widgets, add/remove pages, and customize dock style (Glass, Transparent, Solid, Hidden).
   - Long-press any app icon for quick actions (Edit label/icon style, Remove from Home, App Info, or System Shortcuts via `LauncherApps` when default launcher).
3. **App Drawer & Instant Local Search**:
   - Swipe up (or tap dock drawer handle) to reveal the App Drawer with vertical or horizontal paging, A–Z fast index scrub, category tabs, Frequently/Recently Used row (tracked locally on launch), custom grid columns, glass/transparent backdrop, and "Hide from Launcher View" controls (clearly labeled as visual hiding, not encryption).
   - Built-in Search bar queries installed apps, launcher settings, local search history, shortcuts, optional on-device Contacts (when permission granted), and Android Speech Recognizer (when available).
4. **Onboard Algorithmic `ThemeGenerator` Screen**:
   - Users enter any natural-language theme description (e.g., *"Sunset amber glass with deep charcoal amoled dock and crisp minimal icons"*).
   - An onboard deterministic NLP + color-harmony algorithm tokenizes mood, color cues, contrast targets, glass opacity, icon geometry, and wallpaper pattern rules in milliseconds—generating a complete **5-token M3 palette** (Primary, Secondary, Tertiary, Surface, Background + Accent Glow), live swatch preview, and one-tap **Apply to Launcher** / **Save Theme** / **Set Wallpaper**.
5. **15-Section Settings Dashboard**:
   - Accessible via Home Edit Mode, Drawer menu, or App Icon: *Home Screen, App Drawer, Icons, Widgets, Folders, Gestures, Animations, Wallpapers, Search, Dock, Themes (`ThemeGenerator` & Presets), Backup & Restore, Performance, Privacy, About Launcher*.

### Visual Identity & Theme

- **Aesthetic Direction**: **ColorOS 7 Luminous Glass** — smooth rounded squircles, airy layered translucency, crisp specular hairlines, and balanced breathing room.
- **Color Tokens & Dynamic Harmonies**: Semantic `MaterialTheme.colorScheme` tokens powered either by built-in presets, wallpaper-derived palettes (`Palette`-style bitmap color extraction), or `ThemeGenerator` algorithmic harmonies (supporting both true `#000000` AMOLED Dark and Porcelain Light surfaces).
- **Typography**: Locally bundled `.ttf` Google Fonts (`Plus Jakarta Sans` for crisp UI legibility, `Space Grotesk` for geometric headings, `Playfair Display` for editorial clock widgets, `JetBrains Mono` for search/telemetry), all scaled in `sp`.
- **Interactive Motion & Adaptive Performance**: Spring-based drawer/folder opens, icon press bounce, and wallpaper parallax in **Balanced/Premium** modes; automatically simplified to instant fades with zero blur/shadows in **Lite Mode**, and paused immediately when `onPause` fires or screen turns off.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Algorithmic + Rule-Based `ThemeGenerator` vs. Cloud/Heavy LLM**
  - *Chosen Approach*: Deterministic multi-stage color-harmony and style-token engine (HSV/HSL color-wheel synthesis, WCAG contrast validation, semantic keyword weighting, and procedural wallpaper/glass parameter binding).
  - *Why*: Guarantees sub-10ms offline generation, zero API keys, zero network latency, and tiny APK footprint on entry-level devices.
  - *Alternatives Considered*: Bundling a multi-hundred-MB on-device LLM (`LiteRT`) was avoided because it violates low-RAM and reasonable installation-size constraints on entry-level phones.

- **Decision 2: Dual Widget System (Custom Glass Widgets + Android `AppWidgetHost`)**
  - *Chosen Approach*: Built-in Compose Glass Widgets (Clock, Calendar, Battery, Notes, Photo, Search, Media, Local Status) plus real `AppWidgetHost` embedding inside `AndroidView` with `BIND_APPWIDGET` flow.
  - *Why*: Custom glass widgets match the ColorOS 7 glassmorphism aesthetic immediately with zero permission friction, while `AppWidgetHost` delivers real third-party Android widget support where the device permits.
  - *Alternatives Considered*: Only `AppWidgetHost` leaves first-launch home screens empty; only custom widgets wouldn't fulfill full Android App Widget hosting.

- **Decision 3: Package Visibility via `<queries>` Intent Filter vs. `QUERY_ALL_PACKAGES`**
  - *Chosen Approach*: Declare standard `<queries>` for `ACTION_MAIN` + `CATEGORY_LAUNCHER` (and `APPWIDGET_CONFIGURE` / speech recognition intents) in `AndroidManifest.xml`, avoiding `QUERY_ALL_PACKAGES` unless explicitly required.
  - *Why*: Respects Google Play policy and least-privilege privacy while discovering all launchable user apps cleanly.

- **Decision 4: Honest System Boundaries for Gestures & Hidden Apps**
  - *Chosen Approach*: Gestures like Double-Tap Lock use an explicit opt-in `DeviceAdminReceiver` prompt; Swipe-Down Notification Shade invokes standard status bar expansion where permitted or displays a clear OEM compatibility notice; Hidden Apps only filter launcher visibility without claiming device-level encryption.
  - *Why*: Prevents misleading security claims and broken/blocked OEM actions.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│                         ANDROID SYSTEM & PLATFORM APIS                       │
│  HOME Intent │ LauncherApps / PackageManager │ AppWidgetHost │ WallpaperMgr  │
└──────┬──────────────────────────────┬───────────────────────────────┬────────┘
       │                              │                               │
       ▼                              ▼                               ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                        LOCAL DATA & PERSISTENCE LAYER                        │
│  ┌──────────────────────────┐    ┌────────────────────────────────────────┐  │
│  │ Room Database            │    │ Jetpack DataStore Preferences          │  │
│  │ • HomeItems (Apps/Folders│    │ • Grid rows/cols, Dock & Drawer config │  │
│  │   /Widgets per page)     │    │ • Gesture mappings & Animation scale   │  │
│  │ • Custom Themes & Notes  │    │ • Active Theme ID & Performance Mode   │  │
│  │ • Search History & Stats │    │ • Hidden packages & Custom app labels  │  │
│  └──────────────┬───────────┘    └───────────────────┬────────────────────┘  │
└─────────────────┼────────────────────────────────────┼───────────────────────┘
                  └─────────────────┬──────────────────┘
                                    ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                       OFFLINE ENGINES & STATE LAYER                          │
│  • LauncherRepository & LauncherViewModel (StateFlow, lifecycle-gated jobs)  │
│  • Algorithmic ThemeGenerator Engine (Text → Color Harmony + Style Tokens)   │
│  • AppCatalogLoader (Bounded LruCache for app icons, alphabetical/category)  │
│  • ProceduralWallpaperRenderer + Bitmap Color Extractor                      │
│  • HardwareCapabilityEngine (Auto / Lite / Balanced / Premium + Tablet Grid) │
└───────────────────────────────────┬──────────────────────────────────────────┘
                                    ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                     ADAPTIVE JETPACK COMPOSE UI SURFACES                     │
│  ┌────────────────┐  ┌──────────────────┐  ┌──────────────────────────────┐  │
│  │ HomePagerHost  │  │ AppDrawerOverlay │  │ FolderModal & EditModeSheet  │  │
│  │ • Adaptive Grid│  │ • Vert / Horiz   │  │ • Drag/Reorder/Resize/Pages  │  │
│  │ • Glass Dock   │  │ • Instant Search │  │ • Custom & AppWidgetHost     │  │
│  │ • Gesture Layer│  │ • Hidden Filter  │  │   placement                  │  │
│  └────────────────┘  └──────────────────┘  └──────────────────────────────┘  │
│  ┌────────────────────────────────────┐  ┌────────────────────────────────┐  │
│  │ ThemeGenerator Screen              │  │ 15-Section Settings Dashboard  │  │
│  │ • Text Prompt → Algorithmic Palette│  │ • Home, Drawer, Icons, Widgets │  │
│  │ • Live Color/Glass/Icon Swatches   │  │ • Folders, Gestures, Perf,     │  │
│  │ • One-Tap Apply to Launcher & WP   │  │   Backup/Restore JSON, Privacy │  │
│  └────────────────────────────────────┘  └────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **Home Screen Items (Room)**: Stores each placed item's type (`APP`, `FOLDER`, `CUSTOM_WIDGET`, `SYSTEM_WIDGET`), page index, grid `(row, col)`, span `(spanX, spanY)`, target package/component or `appWidgetId`, custom label, custom icon override, and folder membership/style.
- **App Catalog & Usage Metadata (Memory + Room)**: `LauncherApps` / `PackageManager` resolves launchable apps on IO dispatcher with a bounded `LruCache<String, Drawable/ImageBitmap>` for icons; local launch counts & timestamps power Recently/Frequently Used sections; Room stores search history and launcher-hosted Notes widget content.
- **Launcher Preferences & Themes (DataStore + Room)**: Stores grid dimensions (dynamically scaled for Phone, Tablet, and Foldables via `WindowSizeClass`), dock configuration, icon pack/shape/size, drawer mode, gesture assignments, hidden package set, active theme ID, and performance mode (`Auto`, `Lite`, `Balanced`, `Premium`).
- **Backup & Restore (JSON via SAF)**: Serializes the complete home layout, folder structures, custom labels, active theme, and settings into a portable `.json` file via Android's Storage Access Framework (`CreateDocument` / `OpenDocument`).

### Interactive Component & State Mapping

- **Home Screen & Gestures**: Swipe-up triggers `AppDrawer` state; pinch or long-press opens `EditMode`; swipe-left/right pages `HorizontalPager` with selected transition; double-tap triggers opt-in `DeviceAdmin` lock or clear prompt; two-finger swipe runs user-assigned shortcut (ThemeGenerator, Search, Settings, or Drawer).
- **Edit Mode & Folder System**: Tapping an empty slot or "+ Widget / + Page" mutates Room layout entities reactively; dragging or tapping "Group into Folder" creates/updates a `Folder` entity with live modal expansion and custom color/layout (`Grid` vs `Stack`, `Rounded` vs `Glass` vs `Transparent`).
- **`ThemeGenerator` Screen**: User enters descriptive text → `ThemeGeneratorEngine` computes HSV color harmonies (Primary, Secondary, Tertiary, Surface, Background, Glow), validates AA text contrast, selects glass/icon/wallpaper presets, renders a live preview card, and updates DataStore + Room when applied.
- **Lifecycle & Low-End Optimization**: `MainActivity` (`launchMode="singleTask"`, `HOME` category) pauses all decorative animations and cancels non-essential preview coroutines on `onPause`, evicts icon/wallpaper caches on `onTrimMemory`, and runs zero persistent background services.
